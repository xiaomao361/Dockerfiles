"""Django Apps Config"""

from django.apps import AppConfig


class TermsAndConditionsConfig(AppConfig):
    name = 'termsandconditions'
    verbose_name = "Terms and Conditions"
